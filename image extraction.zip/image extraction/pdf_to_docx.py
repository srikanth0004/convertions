from pdf2docx import parse

pdf_file = 'C290T64AdmitCard.pdf'
docx_file = 'sample.docx'

# convert pdf to docx
parse(pdf_file, docx_file)