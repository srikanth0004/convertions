import json
import docx

doc = docx.Document('C290T64AdmitCard.docx') 
text = "\n".join([paragraph.text for paragraph in doc.paragraphs])

# Convert text to JSON format
data = {"text": text}
json_data = json.dumps(data)

# Save as a JSON file
with open('C290T64AdmitCard.json', 'w') as json_file:
    json_file.write(json_data)


