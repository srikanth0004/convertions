import mammoth

input_filename = "manager's HRhandbook V1.0.docx"


with open(input_filename, "rb") as docx_file:
    result = mammoth.convert_to_html(docx_file)
    html = result.value 


output_filename = "output3.html"
with open(output_filename, "w") as f: 
    f.writelines(html)