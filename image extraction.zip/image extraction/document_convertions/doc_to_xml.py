from docx_utils.flatten import opc_to_flat_opc

opc_to_flat_opc("manager's HRhandbook V1.0.docx", "sample3.xml")