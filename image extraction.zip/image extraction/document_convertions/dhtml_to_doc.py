from htmldocx import HtmlToDocx

new_parser = HtmlToDocx()
new_parser.parse_html_file("admitcard.html", "admitcardsample")